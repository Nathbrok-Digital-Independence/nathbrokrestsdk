# Nathbrok REST SDK

`nathbrokrestsdk` is a Python client library for the Nathbrok REST APIs. It
provides HMAC request signing, optional encrypted server requests, and clients
for chat, cloud storage, mail, and data encryption.

## Requirements

- Python 3.10 or later
- A Nathbrok server access key ID, one-time access key, and signing secret

## Install

From this directory, install the package with:

```shell
python -m pip install .
```

The package installs its runtime dependencies (`requests` and `cryptography`).

## Initialize authentication

Keep credentials outside source control. The initialization call validates the
access key and retrieves the server's public encryption key.

```python
import os

from nathbrokrestsdk.auth import Auth

auth = Auth()
auth.initialize(
    access_key_id=os.environ["NATHBROK_ACCESS_KEY_ID"],
    access_key=os.environ["NATHBROK_ACCESS_KEY"],
    secret_key=os.environ["NATHBROK_SECRET_KEY"],
)
```

`Auth` signs requests with the configured secret. Calls that send encrypted
requests use the server key fetched during initialization. API failures are
raised as `NathbrokAPIError`:

```python
from nathbrokrestsdk.auth import NathbrokAPIError

try:
    sso_url = auth.create_sso_url("user@example.com")
except NathbrokAPIError as exc:
    print(exc.status_code, exc)
```

`Auth` also accepts a custom `base_url` and `timeout` when constructing it.
Use HTTPS outside local development.

## Chat

Chat operations use local end-to-end encryption for room keys and message
content. Each participant must have usable public-key material registered;
the creator unlocks their private key locally with their passphrase.

```python
from nathbrokrestsdk.chat import ChatClient

chat = ChatClient(auth)
room = chat.create_room(
    name="Project discussion",
    users=["colleague@example.com"],
    passphrase=os.environ["NATHBROK_CHAT_PASSPHRASE"],
    user="owner@nathlink",
)

chat.send_message(
    message=["Hello from the SDK"],
    room_id=room["room_id"],
    sender="owner@nathlink",
    passphrase=os.environ["NATHBROK_CHAT_PASSPHRASE"],
)
```

`ChatClient` also provides methods to unlock rooms, encrypt/decrypt messages,
and delete rooms or messages. Keep passphrases secure; they are used locally to
unlock key material and should not be sent to the API.

## Other clients

- `nathbrokrestsdk.cloud.CloudClient` uploads and manages bucket files.
- `nathbrokrestsdk.mail.MailClient` sends email through an authorized mailbox.
- `nathbrokrestsdk.dde.DDEClient` requests file and data encryption/decryption.

`MailClient` accepts an initialized `Auth` instance:

```python
from nathbrokrestsdk.mail import MailClient

mail = MailClient(auth)
result = mail.send_email(
    {"subject": "Hello", "body_text": "Sent with Nathbrok."},
    mailbox="sender@example.com",
    to="recipient@example.com",
)
```

All clients return decoded JSON response data. Consult the Nathbrok SDK
documentation for endpoint permissions and account setup:
<https://docs.nathbrok.com/sdk/v1/>.

## License

This project is distributed under the MIT License. See [LICENSE](LICENSE).
